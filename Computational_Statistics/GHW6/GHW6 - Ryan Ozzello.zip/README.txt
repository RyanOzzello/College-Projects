The time it took to run NChain and River Swim was enormous due to failed exploration.
This confirms Q-Learning's inability to explore.